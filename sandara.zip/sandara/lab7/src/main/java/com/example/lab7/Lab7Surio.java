package com.example.lab7;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Lab7Surio {

	public static void main(String[] args) {
		SpringApplication.run(Lab7Surio.class, args);
	}

}
